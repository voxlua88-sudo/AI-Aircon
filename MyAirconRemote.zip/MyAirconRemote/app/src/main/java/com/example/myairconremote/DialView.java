package com.example.myairconremote;

import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/**
 * Circular temperature selector: a 270 degree arc with a blue-to-orange gradient and a
 * draggable knob. Draw path allocates nothing (all paints, matrices and tick coordinates
 * are prepared in {@link #onSizeChanged}), so dragging stays at full frame rate.
 */
public class DialView extends View {

    public interface Listener {
        /** Fires on every degree change while dragging (UI only, do no heavy work here). */
        void onTemperatureChanging(int tempC);

        /** Fires once when the finger lifts and the value actually changed. */
        void onTemperatureCommitted(int tempC);

        /** The user touched the dial while it is inactive (AC off). */
        void onInactiveTouch();
    }

    private static final int MIN_TEMP = SharpYb1faEncoder.MIN_TEMP;
    private static final int MAX_TEMP = SharpYb1faEncoder.MAX_TEMP;
    private static final int STEPS = MAX_TEMP - MIN_TEMP;

    private static final float START_ANGLE = 135f;   // bottom-left
    private static final float SWEEP_ANGLE = 270f;   // clockwise to bottom-right

    private static final int COLOR_COOL = 0xFF3B82F6;
    private static final int COLOR_WARM = 0xFFFB923C;
    private static final int COLOR_TRACK = 0xFFE3E8F0;
    private static final int COLOR_DISABLED = 0xFFCBD2DC;
    private static final int COLOR_TICK = 0xFFB8C0CC;

    private final Paint arcPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tickPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint haloPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knobPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF arcRect = new RectF();
    private final Matrix gradientMatrix = new Matrix();
    private final float[] tickX = new float[STEPS + 1];
    private final float[] tickY = new float[STEPS + 1];

    private SweepGradient gradient;
    private float cx, cy, radius, strokeWidth, knobRadius, density, tickRadius;
    private float labelLeftX, labelRightX, labelY;

    private int temp = 24;
    private float shownFraction = fractionOf(24);
    private boolean active = true;
    private boolean dragging;
    private int tempAtTouchStart;
    private ValueAnimator animator;
    private Listener listener;

    public DialView(Context context) {
        super(context);
        init();
    }

    public DialView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public DialView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        density = getResources().getDisplayMetrics().density;

        arcPaint.setStyle(Paint.Style.STROKE);
        arcPaint.setStrokeCap(Paint.Cap.ROUND);

        tickPaint.setStyle(Paint.Style.FILL);
        tickPaint.setColor(COLOR_TICK);

        haloPaint.setStyle(Paint.Style.FILL);
        haloPaint.setColor(0x26000000);

        knobPaint.setStyle(Paint.Style.FILL);
        knobPaint.setColor(Color.WHITE);

        ringPaint.setStyle(Paint.Style.STROKE);

        labelPaint.setColor(0xFF9AA3B2);
        labelPaint.setTextAlign(Paint.Align.CENTER);
        labelPaint.setTextSize(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_SP, 12, getResources().getDisplayMetrics()));

        updateDescription();
    }

    // ------------------------------------------------------------------ public API

    public void setListener(Listener l) {
        this.listener = l;
    }

    public int getTemperature() {
        return temp;
    }

    /** Greys the dial out and ignores drags while the AC is off. */
    public void setActive(boolean on) {
        if (active == on) return;
        active = on;
        if (!on) dragging = false;
        invalidate();
    }

    /** Programmatic update (buttons, voice, restored state). Safe to call from the UI thread. */
    public void setTemperature(int t, boolean animate) {
        t = Math.max(MIN_TEMP, Math.min(MAX_TEMP, t));
        if (dragging) return;
        temp = t;
        updateDescription();
        final float target = fractionOf(t);
        cancelAnimator();
        if (animate && isAttachedToWindow() && Math.abs(target - shownFraction) > 0.001f) {
            animator = ValueAnimator.ofFloat(shownFraction, target);
            animator.setDuration(220);
            animator.setInterpolator(new DecelerateInterpolator());
            animator.addUpdateListener(a -> {
                shownFraction = (Float) a.getAnimatedValue();
                invalidate();
            });
            animator.start();
        } else {
            shownFraction = target;
            invalidate();
        }
    }

    // ------------------------------------------------------------------ measure / layout

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        final int maxPx = (int) (340 * getResources().getDisplayMetrics().density);
        int size = MeasureSpec.getMode(widthSpec) == MeasureSpec.UNSPECIFIED
                ? maxPx : Math.min(MeasureSpec.getSize(widthSpec), maxPx);
        if (MeasureSpec.getMode(heightSpec) != MeasureSpec.UNSPECIFIED) {
            size = Math.min(size, MeasureSpec.getSize(heightSpec));
        }
        setMeasuredDimension(size, size);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        final float size = Math.min(w, h);
        cx = w / 2f;
        cy = h / 2f;
        strokeWidth = size * 0.07f;
        knobRadius = strokeWidth * 0.95f;
        radius = size / 2f - knobRadius - 4 * density;
        tickRadius = radius - strokeWidth * 1.15f;
        arcRect.set(cx - radius, cy - radius, cx + radius, cy + radius);

        arcPaint.setStrokeWidth(strokeWidth);
        ringPaint.setStrokeWidth(strokeWidth * 0.24f);

        gradient = new SweepGradient(cx, cy,
                new int[] { COLOR_COOL, COLOR_WARM, COLOR_WARM },
                new float[] { 0f, SWEEP_ANGLE / 360f, 1f });
        gradientMatrix.setRotate(START_ANGLE, cx, cy);
        gradient.setLocalMatrix(gradientMatrix);

        for (int i = 0; i <= STEPS; i++) {
            final double a = Math.toRadians(START_ANGLE + SWEEP_ANGLE * i / STEPS);
            tickX[i] = cx + tickRadius * (float) Math.cos(a);
            tickY[i] = cy + tickRadius * (float) Math.sin(a);
        }

        final double s = Math.toRadians(START_ANGLE);
        final double e = Math.toRadians(START_ANGLE + SWEEP_ANGLE);
        labelLeftX = cx + radius * (float) Math.cos(s);
        labelRightX = cx + radius * (float) Math.cos(e);
        labelY = cy + radius * (float) Math.sin(s) + strokeWidth * 1.9f;
    }

    // ------------------------------------------------------------------ drawing

    @Override
    protected void onDraw(Canvas canvas) {
        final float frac = shownFraction;

        if (active) {
            arcPaint.setShader(gradient);
            arcPaint.setAlpha(55);                       // faint full-range gradient "track"
            canvas.drawArc(arcRect, START_ANGLE, SWEEP_ANGLE, false, arcPaint);
            arcPaint.setAlpha(255);                      // bright progress arc
            canvas.drawArc(arcRect, START_ANGLE, SWEEP_ANGLE * frac, false, arcPaint);
        } else {
            arcPaint.setShader(null);
            arcPaint.setColor(COLOR_TRACK);
            canvas.drawArc(arcRect, START_ANGLE, SWEEP_ANGLE, false, arcPaint);
        }

        final float tickR = 1.6f * density;
        for (int i = 0; i <= STEPS; i++) {
            canvas.drawCircle(tickX[i], tickY[i], tickR, tickPaint);
        }

        canvas.drawText(MIN_TEMP + "\u00B0", labelLeftX, labelY, labelPaint);
        canvas.drawText(MAX_TEMP + "\u00B0", labelRightX, labelY, labelPaint);

        final double a = Math.toRadians(START_ANGLE + SWEEP_ANGLE * frac);
        final float kx = cx + radius * (float) Math.cos(a);
        final float ky = cy + radius * (float) Math.sin(a);

        canvas.drawCircle(kx, ky + 2 * density, knobRadius * 1.25f, haloPaint);
        canvas.drawCircle(kx, ky, knobRadius, knobPaint);
        ringPaint.setColor(active ? blend(COLOR_COOL, COLOR_WARM, frac) : COLOR_DISABLED);
        canvas.drawCircle(kx, ky, knobRadius - ringPaint.getStrokeWidth() / 2f, ringPaint);
    }

    // ------------------------------------------------------------------ touch

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        final float x = e.getX();
        final float y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                if (!active) {
                    if (listener != null) listener.onInactiveTouch();
                    return false;
                }
                if (Math.hypot(x - cx, y - cy) < radius * 0.45f) {
                    return false;                         // ignore touches near the centre
                }
                dragging = true;
                tempAtTouchStart = temp;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                moveTo(x, y, false);
                return true;
            }
            case MotionEvent.ACTION_MOVE:
                if (!dragging) return false;
                moveTo(x, y, true);
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (!dragging) return false;
                dragging = false;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                if (temp != tempAtTouchStart && listener != null) {
                    listener.onTemperatureCommitted(temp);
                }
                return true;
            default:
                return super.onTouchEvent(e);
        }
    }

    private void moveTo(float x, float y, boolean guardJumps) {
        double deg = Math.toDegrees(Math.atan2(y - cy, x - cx));
        if (deg < 0) deg += 360.0;
        double rel = deg - START_ANGLE;
        if (rel < 0) rel += 360.0;

        final int t;
        if (rel > SWEEP_ANGLE) {
            // Finger is in the dead zone at the bottom: stick to the nearer end.
            t = shownFraction >= 0.5f ? MAX_TEMP : MIN_TEMP;
        } else {
            t = MIN_TEMP + (int) Math.round(rel / SWEEP_ANGLE * STEPS);
        }
        // Stops a drag from teleporting 30 -> 16 when crossing the dead zone.
        if (guardJumps && Math.abs(t - temp) > 8) return;
        if (t == temp) return;

        temp = t;
        shownFraction = fractionOf(t);
        cancelAnimator();
        invalidate();
        performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
        updateDescription();
        if (listener != null) listener.onTemperatureChanging(t);
    }

    // ------------------------------------------------------------------ helpers

    private static float fractionOf(int t) {
        return (t - MIN_TEMP) / (float) STEPS;
    }

    private static int blend(int a, int b, float t) {
        final float u = Math.max(0f, Math.min(1f, t));
        return Color.rgb(
                (int) (Color.red(a) + (Color.red(b) - Color.red(a)) * u),
                (int) (Color.green(a) + (Color.green(b) - Color.green(a)) * u),
                (int) (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * u));
    }

    private void cancelAnimator() {
        if (animator != null) {
            animator.cancel();
            animator = null;
        }
    }

    private void updateDescription() {
        setContentDescription("Temperature dial, " + temp + " degrees Celsius");
    }

    @Override
    protected void onDetachedFromWindow() {
        cancelAnimator();
        super.onDetachedFromWindow();
    }
}
