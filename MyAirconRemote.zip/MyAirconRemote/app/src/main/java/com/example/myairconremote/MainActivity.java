package com.example.myairconremote;

import static com.example.myairconremote.SharpYb1faEncoder.CARRIER_HZ;
import static com.example.myairconremote.SharpYb1faEncoder.CMD_POWER_OFF;
import static com.example.myairconremote.SharpYb1faEncoder.CMD_POWER_ON;
import static com.example.myairconremote.SharpYb1faEncoder.CMD_STATE;
import static com.example.myairconremote.SharpYb1faEncoder.CMD_SWING;
import static com.example.myairconremote.SharpYb1faEncoder.FAN_AUTO;
import static com.example.myairconremote.SharpYb1faEncoder.FAN_HIGH;
import static com.example.myairconremote.SharpYb1faEncoder.FAN_LOW;
import static com.example.myairconremote.SharpYb1faEncoder.FAN_MED;
import static com.example.myairconremote.SharpYb1faEncoder.MAX_TEMP;
import static com.example.myairconremote.SharpYb1faEncoder.MIN_TEMP;
import static com.example.myairconremote.SharpYb1faEncoder.MODE_AUTO;
import static com.example.myairconremote.SharpYb1faEncoder.MODE_COOL;
import static com.example.myairconremote.SharpYb1faEncoder.MODE_DRY;
import static com.example.myairconremote.SharpYb1faEncoder.MODE_HEAT;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.hardware.ConsumerIrManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Offline voice-controlled remote for a Sharp AC (YB1FA) using the phone's IR blaster.
 *
 * <p>Threading model:
 * <ul>
 *   <li><b>Main thread</b>: all UI, haptics, and the {@link SpeechRecognizer} object. Android
 *       requires SpeechRecognizer to be created and driven from the main thread (it throws
 *       otherwise); it does its real work in a separate system service process, so it never
 *       blocks the UI.</li>
 *   <li><b>"ac-ir" executor</b>: builds the pattern and calls ConsumerIrManager.transmit,
 *       which can block for hundreds of milliseconds. Older queued settings frames are dropped
 *       when a newer one arrives, so a burst of changes sends only the latest.</li>
 *   <li><b>"ac-nlp" executor</b>: parses the recognised sentence into a command.</li>
 * </ul>
 * UI and persisted state are updated first, so the dial reacts instantly; the IR frame follows.
 */
public class MainActivity extends Activity implements DialView.Listener {

    private static final String TAG = "SharpAC";

    private static final String PREFS = "sharp_yb1fa_state";
    private static final String K_POWER = "power";
    private static final String K_TEMP = "temp";
    private static final String K_MODE = "mode";
    private static final String K_FAN = "fan";
    private static final String K_SWING = "swing";

    private static final int REQ_AUDIO = 101;

    /** Some units want the frame twice. Raise to 2 if your AC misses single frames. */
    private static final int FRAME_REPEATS = 1;

    private static final int[] MODE_CYCLE = { MODE_COOL, MODE_DRY, MODE_AUTO, MODE_HEAT };
    private static final int[] FAN_CYCLE = { FAN_AUTO, FAN_LOW, FAN_MED, FAN_HIGH };
    private static final String[] MODE_NAMES = { "Auto", "Cool", "Dry", "Heat" }; // index = MODE_*
    private static final String[] FAN_NAMES = { "Auto", "Low", "Medium", "High" }; // index = FAN_*

    private static final int ST_READY = 0;
    private static final int ST_BUSY = 1;
    private static final int ST_SENDING = 2;
    private static final int ST_ERROR = 3;

    /** Mutable AC state. Touched on the main thread only; workers receive copied values. */
    private static final class AcState {
        boolean power = false;
        int temp = 24;
        int mode = MODE_COOL;
        int fan = FAN_AUTO;
        boolean swing = false;
    }

    private final AcState state = new AcState();

    // --- views
    private DialView dial;
    private View centerCard;
    private View statusDot;
    private TextView statusText, tempText, stateText, hintText, lblMode, lblFan;
    private ImageView centerModeIcon;
    private ImageButton btnPower, btnMode, btnFan, btnSwing, btnVoice;

    // --- infrastructure
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private ExecutorService irExecutor;
    private ExecutorService nlpExecutor;
    private final AtomicInteger stateSeq = new AtomicInteger();
    private SharedPreferences prefs;

    private ConsumerIrManager irManager;
    private boolean irAvailable;
    private volatile int carrierHz = CARRIER_HZ;

    private SpeechRecognizer speech;
    private boolean listening;
    private TextToSpeech tts;
    private boolean ttsReady;
    private boolean destroyed;

    private final Runnable resetStatus = this::refreshStatus;

    // =================================================================== lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        irExecutor = Executors.newSingleThreadExecutor(r -> new Thread(() -> {
            Process.setThreadPriority(Process.THREAD_PRIORITY_DEFAULT);
            r.run();
        }, "ac-ir"));
        nlpExecutor = Executors.newSingleThreadExecutor(r -> new Thread(() -> {
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);
            r.run();
        }, "ac-nlp"));

        bindViews();
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        loadState();
        initIr();
        initTts();
        wireListeners();
        renderState(false);
        refreshStatus();
        if (!irAvailable) showHint(getString(R.string.hint_no_ir));
    }

    @Override
    protected void onPause() {
        cancelListening();
        if (tts != null) tts.stop();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        mainHandler.removeCallbacksAndMessages(null);
        destroyRecognizer();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }
        irExecutor.shutdownNow();
        nlpExecutor.shutdownNow();
        super.onDestroy();
    }

    // =================================================================== setup

    private void bindViews() {
        dial = findViewById(R.id.dialView);
        centerCard = findViewById(R.id.centerCard);
        statusDot = findViewById(R.id.statusDot);
        statusText = findViewById(R.id.statusText);
        tempText = findViewById(R.id.tempText);
        stateText = findViewById(R.id.stateText);
        hintText = findViewById(R.id.hintText);
        lblMode = findViewById(R.id.lblMode);
        lblFan = findViewById(R.id.lblFan);
        centerModeIcon = findViewById(R.id.modeIcon);
        btnPower = findViewById(R.id.btnPower);
        btnMode = findViewById(R.id.btnMode);
        btnFan = findViewById(R.id.btnFan);
        btnSwing = findViewById(R.id.btnSwing);
        btnVoice = findViewById(R.id.btnVoice);
    }

    private void wireListeners() {
        dial.setListener(this);

        // Keep the white centre circle at ~62% of whatever size the dial ends up with.
        dial.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> {
            final int d = Math.round((r - l) * 0.62f);
            final android.view.ViewGroup.LayoutParams lp = centerCard.getLayoutParams();
            if (d > 0 && (lp.width != d || lp.height != d)) {
                lp.width = d;
                lp.height = d;
                centerCard.setLayoutParams(lp);
            }
        });

        btnPower.setOnClickListener(v -> {
            tap(v);
            setPower(!state.power);
        });
        btnMode.setOnClickListener(v -> {
            tap(v);
            state.mode = next(MODE_CYCLE, state.mode);
            afterSettingChange();
        });
        btnFan.setOnClickListener(v -> {
            tap(v);
            state.fan = next(FAN_CYCLE, state.fan);
            afterSettingChange();
        });
        btnSwing.setOnClickListener(v -> {
            tap(v);
            toggleSwing();
        });
        btnVoice.setOnClickListener(v -> {
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            toggleListening();
        });
    }

    private void initIr() {
        try {
            irManager = (ConsumerIrManager) getSystemService(Context.CONSUMER_IR_SERVICE);
            irAvailable = irManager != null && irManager.hasIrEmitter();
        } catch (Exception e) {
            Log.w(TAG, "IR service unavailable", e);
            irAvailable = false;
        }
        if (irAvailable) {
            // Ask the hardware which carrier it supports, off the main thread.
            try {
                irExecutor.execute(() -> carrierHz = pickCarrier());
            } catch (RejectedExecutionException ignored) { }
        }
    }

    /** Returns 38 kHz if the blaster supports it, otherwise the closest supported frequency. */
    private int pickCarrier() {
        try {
            final ConsumerIrManager.CarrierFrequencyRange[] ranges =
                    irManager.getCarrierFrequencies();
            if (ranges == null || ranges.length == 0) return CARRIER_HZ;
            int best = CARRIER_HZ;
            int bestDist = Integer.MAX_VALUE;
            for (ConsumerIrManager.CarrierFrequencyRange r : ranges) {
                final int lo = r.getMinFrequency();
                final int hi = r.getMaxFrequency();
                if (CARRIER_HZ >= lo && CARRIER_HZ <= hi) return CARRIER_HZ;
                final int dist = CARRIER_HZ < lo ? lo - CARRIER_HZ : CARRIER_HZ - hi;
                if (dist < bestDist) {
                    bestDist = dist;
                    best = CARRIER_HZ < lo ? lo : hi;
                }
            }
            return best;
        } catch (Exception e) {
            return CARRIER_HZ;
        }
    }

    private void initTts() {
        tts = new TextToSpeech(getApplicationContext(), status -> {
            if (status == TextToSpeech.SUCCESS && tts != null) {
                final int r = tts.setLanguage(Locale.getDefault());
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA
                        && r != TextToSpeech.LANG_NOT_SUPPORTED;
            }
        });
    }

    // =================================================================== state + persistence

    private void loadState() {
        state.power = prefs.getBoolean(K_POWER, false);
        state.temp = Math.max(MIN_TEMP, Math.min(MAX_TEMP, prefs.getInt(K_TEMP, 24)));
        final int mode = prefs.getInt(K_MODE, MODE_COOL);
        final int fan = prefs.getInt(K_FAN, FAN_AUTO);
        state.mode = (mode >= MODE_AUTO && mode <= MODE_HEAT) ? mode : MODE_COOL;
        state.fan = (fan >= FAN_AUTO && fan <= FAN_HIGH) ? fan : FAN_AUTO;
        state.swing = prefs.getBoolean(K_SWING, false);
    }

    /** apply() writes to disk asynchronously, so this never blocks the UI thread. */
    private void persist() {
        prefs.edit()
                .putBoolean(K_POWER, state.power)
                .putInt(K_TEMP, state.temp)
                .putInt(K_MODE, state.mode)
                .putInt(K_FAN, state.fan)
                .putBoolean(K_SWING, state.swing)
                .apply();
    }

    // =================================================================== user actions

    private void setPower(boolean on) {
        if (state.power == on) return;
        state.power = on;
        persist();
        renderState(true);                           // instant visual feedback first...
        transmit(on ? CMD_POWER_ON : CMD_POWER_OFF); // ...then the hardware frame
    }

    private void toggleSwing() {
        if (!state.power) {
            showHint(getString(R.string.hint_turn_on_first));
            return;
        }
        state.swing = !state.swing;
        persist();
        renderState(true);
        transmit(CMD_SWING);
    }

    private void afterSettingChange() {
        persist();
        renderState(true);
        if (state.power) {
            transmit(CMD_STATE);
        } else {
            showHint(getString(R.string.hint_saved));
        }
    }

    // --- DialView.Listener

    @Override
    public void onTemperatureChanging(int tempC) {
        state.temp = tempC;
        tempText.setText(getString(R.string.temp_format, tempC));
    }

    @Override
    public void onTemperatureCommitted(int tempC) {
        state.temp = tempC;
        persist();
        transmit(CMD_STATE);
    }

    @Override
    public void onInactiveTouch() {
        showHint(getString(R.string.hint_turn_on_first));
    }

    // =================================================================== IR transmission

    private void transmit(final int cmd) {
        if (!irAvailable) {
            setStatus(ST_ERROR, getString(R.string.status_no_ir));
            showHint(getString(R.string.hint_no_ir));
            return;
        }
        // Snapshot on the main thread; the worker never touches mutable UI state.
        final int temp = state.temp;
        final int mode = state.mode;
        final int fan = state.fan;
        final int seq = (cmd == CMD_SWING) ? stateSeq.get() : stateSeq.incrementAndGet();

        setStatus(ST_SENDING, getString(R.string.status_sending));
        try {
            irExecutor.execute(() -> {
                // A newer settings frame is queued: this one is obsolete, skip it.
                if (cmd == CMD_STATE && seq != stateSeq.get()) return;
                String error = null;
                try {
                    final byte[] frame = SharpYb1faEncoder.buildFrame(cmd, temp, mode, fan);
                    final int[] pattern = SharpYb1faEncoder.toPattern(frame, FRAME_REPEATS);
                    Log.d(TAG, "TX cmd=" + cmd + " frame=" + SharpYb1faEncoder.toHex(frame));
                    irManager.transmit(carrierHz, pattern);
                } catch (SecurityException e) {
                    error = "IR permission denied";
                } catch (Exception e) {
                    error = String.valueOf(e.getMessage());
                }
                final String err = error;
                mainHandler.post(() -> onTransmitDone(err));
            });
        } catch (RejectedExecutionException ignored) {
            // Activity is shutting down.
        }
    }

    private void onTransmitDone(String error) {
        if (destroyed) return;
        if (error != null) {
            setStatus(ST_ERROR, getString(R.string.status_ir_error));
            showHint(error);
            return;
        }
        setStatus(ST_READY, getString(R.string.status_sent));
        mainHandler.removeCallbacks(resetStatus);
        mainHandler.postDelayed(resetStatus, 1500);
    }

    // =================================================================== speech recognition

    private void toggleListening() {
        if (listening) {
            cancelListening();
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] { Manifest.permission.RECORD_AUDIO }, REQ_AUDIO);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            showHint("Speech recognition is not available. Install or enable the Google "
                    + "app, and download an offline speech pack.");
            return;
        }
        if (tts != null) tts.stop();   // never listen to our own voice

        try {
            if (speech == null) {
                speech = SpeechRecognizer.createSpeechRecognizer(this);
                speech.setRecognitionListener(recognitionListener);
            }
            final Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag());
            i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);   // zero-internet operation
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
            i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
            setListeningUi(true);
            speech.startListening(i);
        } catch (Exception e) {
            Log.w(TAG, "startListening failed", e);
            setListeningUi(false);
            destroyRecognizer();
            showHint("Could not start the microphone. Try again.");
        }
    }

    private void cancelListening() {
        if (!listening) return;
        try {
            if (speech != null) speech.cancel();
        } catch (Exception ignored) { }
        setListeningUi(false);
    }

    private void destroyRecognizer() {
        listening = false;
        if (speech != null) {
            try {
                speech.destroy();
            } catch (Exception ignored) { }
            speech = null;
        }
    }

    private void setListeningUi(boolean on) {
        listening = on;
        btnVoice.setSelected(on);
        refreshStatus();
        if (on) showHint("Listening\u2026 try \u201Cset to 24\u201D");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_AUDIO) return;
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            toggleListening();
        } else {
            showHint("Microphone permission is needed for voice control. "
                    + "The dial and buttons still work without it.");
        }
    }

    private final RecognitionListener recognitionListener = new RecognitionListener() {
        @Override public void onReadyForSpeech(Bundle params) { }
        @Override public void onBeginningOfSpeech() { }
        @Override public void onRmsChanged(float rmsdB) { }
        @Override public void onBufferReceived(byte[] buffer) { }
        @Override public void onEndOfSpeech() { }
        @Override public void onPartialResults(Bundle partialResults) { }
        @Override public void onEvent(int eventType, Bundle params) { }

        @Override
        public void onResults(Bundle results) {
            setListeningUi(false);
            final ArrayList<String> list =
                    results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (list == null || list.isEmpty()) {
                unrecognised("");
                return;
            }
            showHint("Heard: \u201C" + list.get(0) + "\u201D");
            dispatchVoice(new ArrayList<>(list));
        }

        @Override
        public void onError(int error) {
            setListeningUi(false);
            switch (error) {
                case SpeechRecognizer.ERROR_NO_MATCH:
                case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                    showHint("Didn\u2019t catch that. Tap the mic and try again.");
                    break;
                case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                    requestPermissions(new String[] { Manifest.permission.RECORD_AUDIO },
                            REQ_AUDIO);
                    break;
                case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                    destroyRecognizer();   // rebuilt on next tap
                    showHint("Speech service was busy. Tap the mic again.");
                    break;
                case SpeechRecognizer.ERROR_AUDIO:
                    showHint("Microphone error. Check that no other app is using it.");
                    break;
                case SpeechRecognizer.ERROR_NETWORK:
                case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                case SpeechRecognizer.ERROR_SERVER:
                case SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE:
                case SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED:
                    showHint("Offline speech pack missing. Download your language in the "
                            + "Google app: Settings > Voice > Offline speech recognition.");
                    break;
                default:
                    destroyRecognizer();
                    showHint("Voice input interrupted. Tap the mic to retry.");
            }
        }
    };

    // =================================================================== voice -> action

    private void dispatchVoice(final ArrayList<String> alternatives) {
        try {
            nlpExecutor.execute(() -> {
                VoiceCommand found = null;
                String heard = alternatives.get(0);
                for (String alt : alternatives) {          // best alternative that parses wins
                    final VoiceCommand c = VoiceParser.parse(alt);
                    if (c != null) {
                        found = c;
                        heard = alt;
                        break;
                    }
                }
                final VoiceCommand cmd = found;
                final String text = heard;
                mainHandler.post(() -> {
                    if (destroyed) return;
                    if (cmd == null) unrecognised(text);
                    else executeVoice(cmd);
                });
            });
        } catch (RejectedExecutionException ignored) { }
    }

    private void unrecognised(String heard) {
        final String msg = "Sorry, I didn\u2019t understand that.";
        showHint(heard.isEmpty() ? msg
                : msg + " Heard: \u201C" + heard + "\u201D");
        speak(msg);
    }

    /** Applies a parsed command to state, sends the minimum number of IR frames, and speaks. */
    private void executeVoice(VoiceCommand c) {
        final List<String> say = new ArrayList<>();
        final boolean wasOn = state.power;

        if (c.power == 2) state.power = !state.power;
        else if (c.power >= 0) state.power = (c.power == 1);

        final boolean turningOff = wasOn && !state.power;
        boolean settingsChanged = false;

        if (!turningOff) {
            if (c.temp >= 0) {
                state.temp = Math.max(MIN_TEMP, Math.min(MAX_TEMP, c.temp));
                settingsChanged = true;
                say.add("temperature " + state.temp + " degrees");
            } else if (c.tempDelta != 0) {
                final int t = Math.max(MIN_TEMP, Math.min(MAX_TEMP, state.temp + c.tempDelta));
                if (t == state.temp) {
                    say.add("already at " + (c.tempDelta > 0 ? "maximum" : "minimum")
                            + " temperature");
                } else {
                    state.temp = t;
                    settingsChanged = true;
                    say.add("temperature " + t + " degrees");
                }
            }
            if (c.mode >= 0) {
                state.mode = c.mode;
                settingsChanged = true;
                say.add(MODE_NAMES[state.mode] + " mode");
            } else if (c.modeCycle) {
                state.mode = next(MODE_CYCLE, state.mode);
                settingsChanged = true;
                say.add(MODE_NAMES[state.mode] + " mode");
            }
            if (c.fan >= 0) {
                state.fan = c.fan;
                settingsChanged = true;
                say.add("fan " + FAN_NAMES[state.fan].toLowerCase(Locale.ROOT));
            } else if (c.fanCycle) {
                state.fan = next(FAN_CYCLE, state.fan);
                settingsChanged = true;
                say.add("fan " + FAN_NAMES[state.fan].toLowerCase(Locale.ROOT));
            }
        }

        // Decide which frames to send.
        if (turningOff) {
            transmit(CMD_POWER_OFF);
            say.clear();
            say.add("turning off");
        } else if (!wasOn && state.power) {
            transmit(CMD_POWER_ON);                      // carries the full state
            say.add(0, "turning on");
        } else if (!state.power) {
            if (settingsChanged) say.add("saved, the AC is off");
            else if (c.power < 0 && !c.swing) say.add("the AC is off");
        } else if (settingsChanged) {
            transmit(CMD_STATE);
        } else if (c.power == 1 && say.isEmpty() && !c.swing) {
            say.add("already on");
        }

        if (c.swing) {
            if (state.power) {
                state.swing = !state.swing;
                transmit(CMD_SWING);
                say.add("swing toggled");
            } else {
                say.add("turn the AC on to use swing");
            }
        }

        persist();
        renderState(true);

        final String sentence = say.isEmpty() ? "Done" : join(say);
        showHint(capitalise(sentence));
        speak(sentence);
    }

    private void speak(String text) {
        if (ttsReady && tts != null && !destroyed) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ac-confirm");
        }
    }

    // =================================================================== rendering

    private void renderState(boolean animate) {
        dial.setActive(state.power);
        dial.setTemperature(state.temp, animate);

        tempText.setText(state.power
                ? getString(R.string.temp_format, state.temp)
                : getString(R.string.off));
        stateText.setText(state.power
                ? MODE_NAMES[state.mode] + " \u00B7 Fan " + FAN_NAMES[state.fan]
                : getString(R.string.tap_power));

        final int icon = modeIcon(state.mode);
        centerModeIcon.setImageResource(icon);
        centerModeIcon.setImageTintList(ColorStateList.valueOf(
                state.power ? modeColor(state.mode) : 0xFFB8C0CC));
        btnMode.setImageResource(icon);
        lblMode.setText(MODE_NAMES[state.mode]);
        lblFan.setText(FAN_NAMES[state.fan]);

        btnPower.setSelected(state.power);
        btnSwing.setSelected(state.power && state.swing);

        final float a = state.power ? 1f : 0.5f;
        btnMode.setAlpha(a);
        btnFan.setAlpha(a);
        btnSwing.setAlpha(a);
    }

    private void refreshStatus() {
        if (destroyed) return;
        if (!irAvailable) setStatus(ST_ERROR, getString(R.string.status_no_ir));
        else if (listening) setStatus(ST_BUSY, getString(R.string.status_listening));
        else setStatus(ST_READY, getString(R.string.status_ready));
    }

    private void setStatus(int kind, String text) {
        statusText.setText(text);
        final int color;
        switch (kind) {
            case ST_BUSY:    color = 0xFFF59E0B; break;   // amber
            case ST_SENDING: color = 0xFF2F80ED; break;   // blue
            case ST_ERROR:   color = 0xFFEF4444; break;   // red
            default:         color = 0xFF22C55E; break;   // green
        }
        final Drawable bg = statusDot.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg.mutate()).setColor(color);
        }
    }

    private void showHint(String text) {
        hintText.setText(text);
    }

    private void tap(View v) {
        v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
    }

    // =================================================================== small helpers

    private static int next(int[] cycle, int current) {
        for (int i = 0; i < cycle.length; i++) {
            if (cycle[i] == current) return cycle[(i + 1) % cycle.length];
        }
        return cycle[0];
    }

    private static int modeIcon(int mode) {
        switch (mode) {
            case MODE_DRY:  return R.drawable.ic_mode_dry;
            case MODE_HEAT: return R.drawable.ic_mode_heat;
            case MODE_AUTO: return R.drawable.ic_mode_auto;
            case MODE_COOL:
            default:        return R.drawable.ic_mode_cool;
        }
    }

    private static int modeColor(int mode) {
        switch (mode) {
            case MODE_DRY:  return 0xFF14B8A6;
            case MODE_HEAT: return 0xFFF97316;
            case MODE_AUTO: return 0xFF8B5CF6;
            case MODE_COOL:
            default:        return 0xFF3B82F6;
        }
    }

    private static String join(List<String> parts) {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(parts.get(i));
        }
        return sb.toString();
    }

    private static String capitalise(String s) {
        return s.isEmpty() ? s : Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    // =================================================================== NLP

    /** What the user asked for. -1 / 0 / false mean "not mentioned". */
    static final class VoiceCommand {
        int power = -1;        // 1 on, 0 off, 2 toggle
        int temp = -1;         // absolute 16..30
        int tempDelta = 0;     // relative, in degrees
        int mode = -1;
        boolean modeCycle;
        int fan = -1;
        boolean fanCycle;
        boolean swing;

        boolean isEmpty() {
            return power < 0 && temp < 0 && tempDelta == 0 && mode < 0 && !modeCycle
                    && fan < 0 && !fanCycle && !swing;
        }
    }

    /**
     * Keyword/pattern based intent extraction. Works on a bag of whole words (so "cooler" never
     * triggers "cool mode") and supports compound requests such as
     * "turn on and set it to twenty four in cool mode with low fan".
     */
    static final class VoiceParser {

        private static final Map<String, Integer> TEENS = new HashMap<>();
        private static final Map<String, Integer> UNITS = new HashMap<>();

        static {
            TEENS.put("sixteen", 16);
            TEENS.put("seventeen", 17);
            TEENS.put("eighteen", 18);
            TEENS.put("nineteen", 19);
            final String[] u = { "one", "two", "three", "four", "five", "six", "seven",
                    "eight", "nine" };
            for (int i = 0; i < u.length; i++) UNITS.put(u[i], i + 1);
        }

        static VoiceCommand parse(String raw) {
            if (raw == null) return null;
            final String s = raw.toLowerCase(Locale.ROOT)
                    .replaceAll("[^a-z0-9 ]", " ")
                    .replaceAll("\\s+", " ")
                    .trim();
            if (s.isEmpty()) return null;

            final String[] tok = s.split(" ");
            final Set<String> w = new HashSet<>(Arrays.asList(tok));
            final VoiceCommand c = new VoiceCommand();

            final boolean fanWord = w.contains("fan");
            final boolean swingWord = anyOf(w, "swing", "oscillate", "oscillation", "louver",
                    "louvre", "flap", "flaps");

            // --- power (ignored when the sentence is about swing: "turn swing on")
            if (!swingWord) {
                final boolean off = anyOf(w, "off", "shutdown", "stop", "disable");
                final boolean on = anyOf(w, "on", "start", "enable", "begin");
                if (off) c.power = 0;
                else if (on) c.power = 1;
                else if (anyOf(w, "power", "toggle")) c.power = 2;
            }

            // --- temperature: absolute first, then relative
            if (!swingWord) {
                final int abs = extractTemperature(tok);
                if (abs >= 0) {
                    c.temp = abs;
                } else if (!fanWord) {
                    final boolean up = anyOf(w, "warmer", "hotter", "increase", "raise",
                            "higher", "up", "plus");
                    final boolean down = anyOf(w, "cooler", "colder", "decrease", "lower",
                            "reduce", "down", "minus");
                    if (up != down) c.tempDelta = (up ? 1 : -1) * deltaAmount(tok);
                }
            }

            // --- mode
            if (anyOf(w, "cool", "cooling", "cold")) c.mode = MODE_COOL;
            else if (anyOf(w, "dry", "dehumidify", "dehumidifier", "humidity")) c.mode = MODE_DRY;
            else if (anyOf(w, "heat", "heating", "warm")) c.mode = MODE_HEAT;
            else if (!fanWord && anyOf(w, "auto", "automatic")) c.mode = MODE_AUTO;
            else if (!fanWord && !swingWord && w.contains("mode")) c.modeCycle = true;

            // --- fan
            if (fanWord) {
                if (anyOf(w, "auto", "automatic")) c.fan = FAN_AUTO;
                else if (anyOf(w, "low", "slow", "quiet", "silent", "minimum", "min", "gentle"))
                    c.fan = FAN_LOW;
                else if (anyOf(w, "medium", "mid", "middle", "normal")) c.fan = FAN_MED;
                else if (anyOf(w, "high", "max", "maximum", "fast", "strong", "turbo", "full"))
                    c.fan = FAN_HIGH;
                else if (c.power < 0) c.fanCycle = true;   // "turn on the fan" is just power on
            }

            // --- swing
            if (swingWord) c.swing = true;

            return c.isEmpty() ? null : c;
        }

        private static boolean anyOf(Set<String> words, String... candidates) {
            for (String cnd : candidates) {
                if (words.contains(cnd)) return true;
            }
            return false;
        }

        /** Finds 16..30 as digits ("24", "24c") or words ("twenty four", "sixteen", "thirty"). */
        private static int extractTemperature(String[] tok) {
            for (int i = 0; i < tok.length; i++) {
                final String t = tok[i];
                if (t.matches("\\d{2}c?")) {
                    final int v = Integer.parseInt(t.substring(0, 2));
                    if (v >= MIN_TEMP && v <= MAX_TEMP) return v;
                    continue;
                }
                final Integer teen = TEENS.get(t);
                if (teen != null) return teen;
                if (t.equals("twenty")) {
                    int v = 20;
                    if (i + 1 < tok.length) {
                        final Integer unit = UNITS.get(tok[i + 1]);
                        if (unit != null) v += unit;
                    }
                    return v;
                }
                if (t.equals("thirty")) return 30;
            }
            return -1;
        }

        /** "warmer by 2", "two degrees cooler" -> 2; default 1. */
        private static int deltaAmount(String[] tok) {
            for (int i = 0; i < tok.length; i++) {
                int n = -1;
                if (tok[i].matches("\\d")) n = Integer.parseInt(tok[i]);
                else if (UNITS.containsKey(tok[i])) n = UNITS.get(tok[i]);
                if (n >= 1 && n <= 5) {
                    final boolean byBefore = i > 0 && tok[i - 1].equals("by");
                    final boolean degreeAfter = i + 1 < tok.length
                            && tok[i + 1].startsWith("degree");
                    if (byBefore || degreeAfter) return n;
                }
            }
            return 1;
        }
    }
}
