package com.example.myairconremote;

/**
 * Builds Sharp air-conditioner IR frames and converts them to the
 * mark/space microsecond pattern expected by
 * {@link android.hardware.ConsumerIrManager#transmit(int, int[])}.
 *
 * <p>Pure Java, no Android dependencies, no shared mutable state: safe to call from any
 * thread and trivial to unit-test.
 *
 * <h3>Protocol model (Sharp "AC" family, 38 kHz, 104 bits = 13 bytes, LSB first)</h3>
 * <pre>
 *   header : mark 3800 us, space 1900 us
 *   bit 0  : mark  470 us, space  500 us
 *   bit 1  : mark  470 us, space 1400 us
 *   footer : mark  470 us   (then an idle gap of 100 ms before any repeat)
 * </pre>
 *
 * <h3>IMPORTANT: verify against your remote</h3>
 * The timings and byte map below follow the publicly documented Sharp AC family
 * (as used by the open-source IRremoteESP8266 project). I could not confirm that the
 * YB1FA remote uses exactly this byte layout. Every layout decision is isolated in the
 * named constants below, so if your AC ignores a command, capture one button press from
 * the real YB1FA remote (an IR receiver such as a TSOP38238 on an Arduino/ESP, or another
 * phone with IR learning), compare the bytes with {@link #toHex(byte[])}, and adjust the
 * constants. Nothing else in the app needs to change.
 */
public final class SharpYb1faEncoder {

    private SharpYb1faEncoder() { }

    // ------------------------------------------------------------------ public API constants

    public static final int CARRIER_HZ = 38_000;

    public static final int MIN_TEMP = 16;
    public static final int MAX_TEMP = 30;

    /** App-level modes (mapped to protocol bits in {@link #modeBits(int)}). */
    public static final int MODE_AUTO = 0;
    public static final int MODE_COOL = 1;
    public static final int MODE_DRY = 2;
    public static final int MODE_HEAT = 3;

    /** App-level fan speeds (mapped to protocol bits in {@link #fanBits(int)}). */
    public static final int FAN_AUTO = 0;
    public static final int FAN_LOW = 1;
    public static final int FAN_MED = 2;
    public static final int FAN_HIGH = 3;

    /** What kind of frame to build. */
    public static final int CMD_STATE = 0;      // normal settings update while the AC is on
    public static final int CMD_POWER_ON = 1;   // off -> on (carries the full state)
    public static final int CMD_POWER_OFF = 2;  // on -> off
    public static final int CMD_SWING = 3;      // vertical swing toggle

    // ------------------------------------------------------------------ timings (microseconds)

    static final int HDR_MARK_US = 3800;
    static final int HDR_SPACE_US = 1900;
    static final int BIT_MARK_US = 470;
    static final int ONE_SPACE_US = 1400;
    static final int ZERO_SPACE_US = 500;
    static final int FRAME_GAP_US = 100_000;

    // ------------------------------------------------------------------ frame layout (edit me)

    static final int FRAME_BYTES = 13;
    private static final int FRAME_BITS = FRAME_BYTES * 8;

    private static final int B_TEMP = 4;     // low nibble = (tempC - 15)
    private static final int B_POWER = 5;    // bit 4 = "power on" flag, low nibble constant 0x1
    private static final int B_MODE = 6;     // bits 0-1 = mode, bits 4-7 = power/special nibble
    private static final int B_FAN = 7;      // bits 4-6 = fan speed
    private static final int B_SPECIAL = 10; // 0x00 normal, 0x06 swing toggle
    private static final int B_CHECK = 12;   // high nibble = checksum, low nibble constant 0x1

    private static final int TEMP_OFFSET = 15;

    private static final int PWR_NORMAL = 0x0;
    private static final int PWR_ON = 0x1;
    private static final int PWR_OFF = 0x2;
    private static final int PWR_SPECIAL = 0x7;

    private static final int SPECIAL_NONE = 0x00;
    private static final int SPECIAL_SWING = 0x06;

    // fixed header bytes and constant filler bytes
    private static final int[] HEADER = { 0xAA, 0x5A, 0xCF, 0x10 };
    private static final int FILL_B8 = 0x08;
    private static final int FILL_B9 = 0x80;
    private static final int FILL_B11 = 0xE0;

    // ------------------------------------------------------------------ public methods

    /** One frame, ready for {@code ConsumerIrManager.transmit(carrierHz, pattern)}. */
    public static int[] encode(int cmd, int tempC, int mode, int fan) {
        return encode(cmd, tempC, mode, fan, 1);
    }

    /** {@code repeats} identical frames separated by the protocol's 100 ms idle gap. */
    public static int[] encode(int cmd, int tempC, int mode, int fan, int repeats) {
        return toPattern(buildFrame(cmd, tempC, mode, fan), repeats);
    }

    /** Builds the 13-byte logical frame (including checksum). */
    public static byte[] buildFrame(int cmd, int tempC, int mode, int fan) {
        final int temp = Math.max(MIN_TEMP, Math.min(MAX_TEMP, tempC));
        final boolean powerOn = cmd != CMD_POWER_OFF;

        final int pwrNibble;
        switch (cmd) {
            case CMD_POWER_ON:  pwrNibble = PWR_ON; break;
            case CMD_POWER_OFF: pwrNibble = PWR_OFF; break;
            case CMD_SWING:     pwrNibble = PWR_SPECIAL; break;
            default:            pwrNibble = PWR_NORMAL; break;
        }
        final int special = (cmd == CMD_SWING) ? SPECIAL_SWING : SPECIAL_NONE;

        final byte[] f = new byte[FRAME_BYTES];
        for (int i = 0; i < HEADER.length; i++) {
            f[i] = (byte) HEADER[i];
        }
        f[B_TEMP] = (byte) ((temp - TEMP_OFFSET) & 0x0F);
        f[B_POWER] = (byte) (0x01 | (powerOn ? 0x10 : 0x00));
        f[B_MODE] = (byte) ((modeBits(mode) & 0x03) | (pwrNibble << 4));
        f[B_FAN] = (byte) ((fanBits(fan) & 0x07) << 4);
        f[8] = (byte) FILL_B8;
        f[9] = (byte) FILL_B9;
        f[B_SPECIAL] = (byte) special;
        f[11] = (byte) FILL_B11;
        f[B_CHECK] = 0x01;
        f[B_CHECK] = (byte) (0x01 | (checksum(f) << 4));
        return f;
    }

    /** Sharp AC checksum: nibble-fold XOR of bytes 0..11 plus the low nibble of byte 12. */
    public static int checksum(byte[] f) {
        int x = 0;
        for (int i = 0; i < FRAME_BYTES - 1; i++) {
            x ^= f[i] & 0xFF;
        }
        x ^= f[FRAME_BYTES - 1] & 0x0F;
        x ^= x >> 4;
        return x & 0x0F;
    }

    public static boolean isChecksumValid(byte[] f) {
        return f != null && f.length == FRAME_BYTES
                && ((f[B_CHECK] >> 4) & 0x0F) == checksum(f);
    }

    /**
     * Expands a logical frame into the alternating mark/space durations (microseconds,
     * always starting with a mark) that ConsumerIrManager expects. Bits go out LSB first.
     */
    public static int[] toPattern(byte[] frame, int repeats) {
        final int n = Math.max(1, repeats);
        final int perFrame = 2 + FRAME_BITS * 2 + 1;       // header + bits + footer mark
        final int[] p = new int[n * perFrame + (n - 1)];   // + one gap between frames
        int i = 0;
        for (int r = 0; r < n; r++) {
            if (r > 0) {
                p[i++] = FRAME_GAP_US;                     // space between two frames
            }
            p[i++] = HDR_MARK_US;
            p[i++] = HDR_SPACE_US;
            for (int b = 0; b < FRAME_BYTES; b++) {
                final int v = frame[b] & 0xFF;
                for (int bit = 0; bit < 8; bit++) {
                    p[i++] = BIT_MARK_US;
                    p[i++] = ((v >> bit) & 1) != 0 ? ONE_SPACE_US : ZERO_SPACE_US;
                }
            }
            p[i++] = BIT_MARK_US;                          // footer mark
        }
        return p;
    }

    /** Hex dump for logcat comparison with a captured remote, e.g. "AA 5A CF 10 ...". */
    public static String toHex(byte[] frame) {
        final StringBuilder sb = new StringBuilder(frame.length * 3);
        for (int i = 0; i < frame.length; i++) {
            if (i > 0) sb.append(' ');
            sb.append(String.format("%02X", frame[i] & 0xFF));
        }
        return sb.toString();
    }

    // ------------------------------------------------------------------ enum -> protocol bits

    static int modeBits(int mode) {
        switch (mode) {
            case MODE_COOL: return 0b10;
            case MODE_DRY:  return 0b11;
            case MODE_HEAT: return 0b01;
            case MODE_AUTO:
            default:        return 0b00;
        }
    }

    static int fanBits(int fan) {
        switch (fan) {
            case FAN_LOW:  return 0b011;
            case FAN_MED:  return 0b110;
            case FAN_HIGH: return 0b101;
            case FAN_AUTO:
            default:       return 0b010;
        }
    }
}
